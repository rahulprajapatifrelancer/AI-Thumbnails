import React from 'react';
import { X } from 'lucide-react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  onClear?: () => void;
}

export const Input: React.FC<InputProps> = ({ label, className = '', onClear, value, ...props }) => {
  return (
    <div className="flex flex-col space-y-1.5">
      <label className="text-sm font-medium text-zinc-400">
        {label}
      </label>
      <div className="relative">
        <input
          value={value}
          className={`w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-white placeholder-zinc-500 transition-all ${onClear && value ? 'pr-10' : ''} ${className}`}
          {...props}
        />
        {onClear && value && (
          <button
            onClick={onClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-zinc-500 hover:text-white rounded-full hover:bg-zinc-800 transition-colors"
            type="button"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};