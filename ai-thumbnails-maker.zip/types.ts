export enum AppStatus {
  IDLE = 'IDLE',
  GENERATING = 'GENERATING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export type AspectRatio = '16:9' | '9:16' | '4:3' | '3:4' | '1:1';

export type TextEffect = 'standard' | 'outline' | 'shadow' | 'neon' | 'gradient' | '3d' | 'glow' | 'distort';

export interface ThumbnailConfig {
  title: string;
  description: string;
  headshot: File | null;
  referenceImage: File | null;
  style: string;
  aspectRatio: AspectRatio;
  textEffect: TextEffect;
  textPosition: { x: number; y: number };
  showText: boolean;
  outlineThickness: number;
  fontSize: number;
  glowColor: string;
  glowIntensity: number;
}

export interface HistoryItem {
  id: string;
  imageUrl: string;
  config: ThumbnailConfig;
  timestamp: number;
}

export const ASPECT_RATIOS: { id: AspectRatio; label: string; tailwindClass: string; description: string }[] = [
  { id: '16:9', label: '16:9', tailwindClass: 'aspect-video', description: 'Video' },
  { id: '9:16', label: '9:16', tailwindClass: 'aspect-[9/16]', description: 'Shorts' },
  { id: '4:3', label: '4:3', tailwindClass: 'aspect-[4/3]', description: 'Standard' },
  { id: '3:4', label: '3:4', tailwindClass: 'aspect-[3/4]', description: 'Portrait' },
  { id: '1:1', label: '1:1', tailwindClass: 'aspect-square', description: 'Square' },
];

export const TEXT_EFFECTS: { id: TextEffect; label: string; description: string }[] = [
  { id: 'standard', label: 'Standard', description: 'Clean bold' },
  { id: 'outline', label: 'Outline', description: 'Max readability' },
  { id: 'shadow', label: 'Shadow', description: 'Deep drop shadow' },
  { id: 'neon', label: 'Neon', description: 'Fixed pink glow' },
  { id: 'glow', label: 'Custom Glow', description: 'Color & intensity' },
  { id: 'gradient', label: 'Gradient', description: 'Vibrant fade' },
  { id: '3d', label: '3D Pop', description: 'Dimensional' },
  { id: 'distort', label: 'Distort', description: 'Wavy effect' },
];

export const THUMBNAIL_STYLES = [
  { id: 'vibrant', name: 'Vibrant & High Contrast', prompt: 'High contrast, vibrant colors, glowing highlights, cinematic depth of field, modern impactful text' },
  { id: 'minimal', name: 'Clean & Minimalist', prompt: 'Clean background, solid colors, professional studio lighting, sans-serif bold typography' },
  { id: 'gaming', name: 'Gaming / Neon', prompt: 'Neon lights, cyberpunk aesthetic, intense action atmosphere, glitch text effects, dark background' },
  { id: 'reaction', name: 'Shock/Reaction', prompt: 'Exaggerated facial expression emphasis, bright yellow or red arrows, intense emotional cues, clickbait style' },
];