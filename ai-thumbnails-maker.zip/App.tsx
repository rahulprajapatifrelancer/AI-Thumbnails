import React, { useState, useRef, useEffect } from 'react';
import { AppStatus, ThumbnailConfig, THUMBNAIL_STYLES, ASPECT_RATIOS, TEXT_EFFECTS, HistoryItem } from './types';
import { generateThumbnail } from './services/gemini';
import { Button } from './components/Button';
import { Input } from './components/Input';
import { Image, Upload, Download, RefreshCw, AlertCircle, Wand2, Youtube, MonitorPlay, Sparkles, Clock, ArrowRight, Type, Move, ImageIcon, Undo2, Redo2, Eye, EyeOff, X, Trash2, Palette, Waves } from 'lucide-react';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [config, setConfig] = useState<ThumbnailConfig>({
    title: '',
    description: '',
    headshot: null,
    referenceImage: null,
    style: THUMBNAIL_STYLES[0].prompt,
    aspectRatio: '16:9',
    textEffect: 'standard',
    textPosition: { x: 75, y: 50 }, // Default position (right side)
    showText: true,
    outlineThickness: 15,
    fontSize: 10, // Percentage of canvas width
    glowColor: '#3b82f6', // Default blue-500
    glowIntensity: 20
  });
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  // Undo/Redo state
  const [positionHistory, setPositionHistory] = useState<{x: number, y: number}[]>([{ x: 75, y: 50 }]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const referenceInputRef = useRef<HTMLInputElement>(null);
  
  // Dragging state
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Ref to track latest position for event listeners
  const textPositionRef = useRef(config.textPosition);

  // Sync ref with state
  useEffect(() => {
    textPositionRef.current = config.textPosition;
  }, [config.textPosition]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'headshot' | 'reference') => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      // Basic validation
      if (file.size > 5 * 1024 * 1024) {
        setError("File size too large. Please upload an image under 5MB.");
        return;
      }
      if (type === 'headshot') {
        setConfig(prev => ({ ...prev, headshot: file }));
      } else {
        setConfig(prev => ({ ...prev, referenceImage: file }));
      }
      setError(null);
    }
  };

  const handleGenerate = async () => {
    if (!config.title.trim()) {
      setError("Please enter a video title.");
      return;
    }
    if (!config.headshot) {
      setError("Please upload a headshot photo.");
      return;
    }

    setStatus(AppStatus.GENERATING);
    setError(null);

    try {
      const imageUrl = await generateThumbnail(
        config.title, 
        config.description,
        config.headshot, 
        config.referenceImage,
        config.style,
        config.aspectRatio,
        config.textEffect
      );
      setGeneratedImage(imageUrl);
      setStatus(AppStatus.SUCCESS);
      
      // Reset text position to default for new generation
      const defaultPos = { x: 75, y: 50 };
      setConfig(prev => ({...prev, textPosition: defaultPos}));
      
      // Reset history for new image
      setPositionHistory([defaultPos]);
      setHistoryIndex(0);

      // Add to history
      const newItem: HistoryItem = {
        id: crypto.randomUUID(),
        imageUrl,
        config: { ...config, textPosition: defaultPos },
        timestamp: Date.now()
      };
      setHistory(prev => [newItem, ...prev]);

    } catch (err: any) {
      setError(err.message || "Failed to generate thumbnail. Please try again.");
      setStatus(AppStatus.ERROR);
    }
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setConfig(prev => ({ ...prev, textPosition: positionHistory[newIndex] }));
    }
  };

  const handleRedo = () => {
    if (historyIndex < positionHistory.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setConfig(prev => ({ ...prev, textPosition: positionHistory[newIndex] }));
    }
  };

  // Drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (status !== AppStatus.SUCCESS) return;
    setIsDragging(true);
    e.preventDefault();
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    // Constrain to 0-100
    const constrainedX = Math.max(0, Math.min(100, x));
    const constrainedY = Math.max(0, Math.min(100, y));

    setConfig(prev => ({
      ...prev,
      textPosition: { x: constrainedX, y: constrainedY }
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    
    // Add to history if position changed significantly
    const currentPos = textPositionRef.current;
    const lastPos = positionHistory[historyIndex];
    
    if (Math.abs(currentPos.x - lastPos.x) > 0.1 || Math.abs(currentPos.y - lastPos.y) > 0.1) {
       const newHistory = positionHistory.slice(0, historyIndex + 1);
       newHistory.push(currentPos);
       setPositionHistory(newHistory);
       setHistoryIndex(newHistory.length - 1);
    }
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, historyIndex, positionHistory]);

  const handleDownload = async () => {
    if (!generatedImage) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new window.Image();
    img.crossOrigin = "anonymous";
    img.src = generatedImage;

    img.onload = async () => {
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;

      // Draw background
      ctx.drawImage(img, 0, 0);

      // Only draw text if showText is true
      if (config.showText) {
        // Wait for fonts to be ready to ensure correct rendering
        await document.fonts.ready;

        // Configure text style
        // Scale font size based on image width and user preference
        const fontSize = Math.floor(canvas.width * (config.fontSize / 100)); 
        const lineHeight = fontSize * 1.1;
        
        // Use 'Black' weight for maximum impact, uppercase matches preview
        ctx.font = `900 ${fontSize}px 'Inter', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const text = config.title.toUpperCase();
        
        // Word Wrap Logic
        const maxWidth = canvas.width * 0.9;
        const words = text.split(' ');
        const lines: string[] = [];
        let currentLine = words[0];

        for (let i = 1; i < words.length; i++) {
          const testLine = currentLine + " " + words[i];
          const metrics = ctx.measureText(testLine);
          if (metrics.width < maxWidth) {
            currentLine = testLine;
          } else {
            lines.push(currentLine);
            currentLine = words[i];
          }
        }
        lines.push(currentLine);

        // Calculate centering for multi-line text block
        const x = (config.textPosition.x / 100) * canvas.width;
        const centerY = (config.textPosition.y / 100) * canvas.height;
        const totalBlockHeight = lines.length * lineHeight;
        const startY = centerY - (totalBlockHeight / 2) + (lineHeight / 2);

        lines.forEach((line, index) => {
          const y = startY + (index * lineHeight);
          ctx.save();

          // Apply Enhanced Text Effects
          switch (config.textEffect) {
            case 'outline':
              // Bold stroke with crisp join
              ctx.lineJoin = 'round';
              ctx.miterLimit = 2;
              // Use user defined thickness. 15 is default which equals 0.15 * fontSize.
              ctx.lineWidth = fontSize * (config.outlineThickness / 100); 
              ctx.strokeStyle = 'black';
              ctx.strokeText(line, x, y);
              ctx.fillStyle = 'white';
              ctx.fillText(line, x, y);
              break;

            case 'shadow':
              // Hard offset shadow (Comic style)
              const shadowOffset = fontSize * 0.08;
              ctx.fillStyle = 'black';
              ctx.fillText(line, x + shadowOffset, y + shadowOffset);
              ctx.fillStyle = 'white';
              ctx.fillText(line, x, y);
              break;

            case 'neon':
              // Glowing effect using multiple layered shadows
              ctx.lineJoin = 'round';
              ctx.fillStyle = 'white';
              
              // Deep outer glow
              ctx.shadowColor = '#d946ef'; // Fuchsia-500
              ctx.shadowBlur = fontSize * 0.6;
              ctx.fillText(line, x, y);

              // Medium intensity glow
              ctx.shadowColor = '#d946ef';
              ctx.shadowBlur = fontSize * 0.3;
              ctx.fillText(line, x, y);

              // Inner bright glow
              ctx.shadowColor = '#f0abfc'; // Fuchsia-300
              ctx.shadowBlur = fontSize * 0.1;
              ctx.fillText(line, x, y);

              // Clean top layer to make text readable inside glow
              ctx.shadowColor = 'transparent';
              ctx.fillText(line, x, y);
              break;
            
            case 'glow':
              // Custom Colored Glow
              ctx.lineJoin = 'round';
              ctx.fillStyle = 'white';
              
              // Customizable outer glow
              ctx.shadowColor = config.glowColor;
              ctx.shadowBlur = fontSize * (config.glowIntensity / 10);
              // Draw multiple times to increase intensity if needed, 
              // but shadowBlur handles spread.
              ctx.fillText(line, x, y);
              // Second pass for core brightness
              ctx.shadowBlur = fontSize * (config.glowIntensity / 30);
              ctx.fillText(line, x, y);
              break;

            case 'distort':
              // Wavy Distort Effect
              ctx.fillStyle = 'white';
              ctx.shadowColor = 'rgba(0,0,0,0.5)';
              ctx.shadowBlur = 5;
              
              const lineMetrics = ctx.measureText(line);
              const lineWidth = lineMetrics.width;
              // Since textAlign is center, the start X for this line is:
              let cursorX = x - (lineWidth / 2);
              
              // Reset alignment for character-by-character drawing
              ctx.textAlign = 'left';
              
              const amplitude = fontSize * 0.15;
              const frequency = 0.5;

              for (let i = 0; i < line.length; i++) {
                const char = line[i];
                const charWidth = ctx.measureText(char).width;
                // Sine wave offset for Y
                const yOffset = Math.sin(i * frequency) * amplitude;
                
                ctx.fillText(char, cursorX, y + yOffset);
                cursorX += charWidth;
              }
              break;

            case 'gradient':
              // Gradient specific to the text line width
              const gradLineWidth = ctx.measureText(line).width;
              const gradient = ctx.createLinearGradient(x - gradLineWidth/2, y - fontSize/2, x + gradLineWidth/2, y + fontSize/2);
              
              // Sunset Gradient
              gradient.addColorStop(0, '#fbbf24'); // Amber-400
              gradient.addColorStop(0.5, '#f97316'); // Orange-500
              gradient.addColorStop(1, '#ef4444'); // Red-500
              
              // Drop shadow for separation
              ctx.shadowColor = 'rgba(0,0,0,0.6)';
              ctx.shadowBlur = fontSize * 0.15;
              ctx.shadowOffsetX = fontSize * 0.05;
              ctx.shadowOffsetY = fontSize * 0.05;

              ctx.fillStyle = gradient;
              ctx.fillText(line, x, y);
              
              // Subtle white stroke to define edges against varied backgrounds
              ctx.shadowColor = 'transparent';
              ctx.lineWidth = fontSize * 0.02;
              ctx.strokeStyle = 'rgba(255,255,255,0.4)';
              ctx.strokeText(line, x, y);
              break;

            case '3d':
              // Retro 3D Extrusion
              const depth = 15; // Number of layers
              const layerOffset = fontSize * 0.01;
              
              ctx.fillStyle = '#18181b'; // Zinc-900 (Dark)
              
              // Draw layers from back to front
              for(let i = depth; i > 0; i--) {
                ctx.fillText(line, x + (i * layerOffset), y + (i * layerOffset));
              }
              
              // Main Face
              ctx.fillStyle = 'white';
              // Slight inner shadow on face to separate from extrusion
              ctx.shadowColor = 'rgba(0,0,0,0.5)';
              ctx.shadowBlur = 2;
              ctx.fillText(line, x, y);
              break;

            default: // standard
              // Clean white text with strong lift
              ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
              ctx.shadowBlur = fontSize * 0.2;
              ctx.shadowOffsetX = 0;
              ctx.shadowOffsetY = fontSize * 0.05;
              
              ctx.fillStyle = 'white';
              ctx.fillText(line, x, y);
              break;
          }

          ctx.restore();
        });
      }

      // Trigger download
      const link = document.createElement('a');
      link.href = canvas.toDataURL('image/png');
      link.download = `thumbnail-${config.title.replace(/\s+/g, '-').toLowerCase()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
  };

  const loadFromHistory = (item: HistoryItem) => {
    setGeneratedImage(item.imageUrl);
    setConfig(item.config);
    setStatus(AppStatus.SUCCESS);
    setPositionHistory([item.config.textPosition]);
    setHistoryIndex(0);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentAspectRatio = ASPECT_RATIOS.find(r => r.id === config.aspectRatio) || ASPECT_RATIOS[0];
  const getTextEffectClass = (effect: string) => {
    switch (effect) {
      case 'outline': return 'text-white font-black drop-shadow-md';
      case 'shadow': return 'text-white drop-shadow-[0_10px_10px_rgba(0,0,0,1)]';
      case 'neon': return 'text-white drop-shadow-[0_0_15px_rgba(236,72,153,0.9)]';
      case 'glow': return 'text-white'; // Style is handled via inline style
      case 'gradient': return 'bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent';
      case '3d': return 'text-white drop-shadow-[4px_4px_0_rgba(0,0,0,1)]';
      case 'distort': return 'text-white'; // No specific class, just white
      default: return 'text-white'; // standard
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f11] text-zinc-100 flex flex-col">
      <header className="border-b border-zinc-800 bg-[#0f0f11]/80 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center shadow-lg shadow-red-500/20">
              <Youtube className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">AI Thumbnails</span>
          </div>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">Documentation</a>
            <div className="w-px h-4 bg-zinc-800"></div>
            <span className="text-xs font-mono text-zinc-500 bg-zinc-900 px-2 py-1 rounded">v1.3.3</span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          <div className="lg:col-span-4 space-y-8">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">
                Create Viral Thumbnails
              </h1>
              <p className="text-zinc-400">
                Generate professional, high-CTR thumbnails for your YouTube videos.
              </p>
            </div>

            <div className="space-y-6 bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800/50">
              <Input 
                label="Video Title" 
                placeholder="e.g., I Built a House Underwater!" 
                value={config.title}
                onChange={(e) => setConfig(prev => ({ ...prev, title: e.target.value }))}
                onClear={() => setConfig(prev => ({ ...prev, title: '' }))}
                maxLength={60}
              />

              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium text-zinc-400">
                  Video Description <span className="text-zinc-600 font-normal">(Optional)</span>
                </label>
                <textarea
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-white placeholder-zinc-500 transition-all resize-none h-24"
                  placeholder="Context for the AI background..."
                  value={config.description}
                  onChange={(e) => setConfig(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-zinc-400">Your Headshot (Required)</label>
                <div 
                  className={`relative group cursor-pointer border-2 border-dashed rounded-xl p-8 transition-all duration-200 text-center ${config.headshot ? 'border-indigo-500 bg-indigo-500/5' : 'border-zinc-700 hover:border-zinc-500 hover:bg-zinc-800/50'}`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/png, image/jpeg, image/webp"
                    onChange={(e) => handleFileChange(e, 'headshot')}
                  />
                  {config.headshot ? (
                    <>
                      <div className="flex flex-col items-center">
                        <div className="w-16 h-16 rounded-full overflow-hidden bg-zinc-800 mb-2 ring-2 ring-indigo-500 ring-offset-2 ring-offset-zinc-900">
                          <img src={URL.createObjectURL(config.headshot)} alt="Preview" className="w-full h-full object-cover" />
                        </div>
                        <p className="text-sm font-medium text-white">{config.headshot.name}</p>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfig(prev => ({ ...prev, headshot: null }));
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="absolute top-2 right-2 p-1.5 hover:bg-zinc-700/50 rounded-full text-zinc-400 hover:text-zinc-200 transition-colors"
                        title="Remove headshot"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3 group-hover:bg-zinc-700 transition-colors"><Upload className="w-5 h-5 text-zinc-400" /></div>
                      <p className="text-sm font-medium text-zinc-300">Upload your photo</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-zinc-400 flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Reference Image</label>
                <div 
                  className={`relative group cursor-pointer border-2 border-dashed rounded-xl p-4 transition-all duration-200 text-center ${config.referenceImage ? 'border-indigo-500 bg-indigo-500/5' : 'border-zinc-800 hover:border-zinc-600 hover:bg-zinc-800/30'}`}
                  onClick={() => referenceInputRef.current?.click()}
                >
                  <input type="file" ref={referenceInputRef} className="hidden" accept="image/png, image/jpeg, image/webp" onChange={(e) => handleFileChange(e, 'reference')} />
                  {config.referenceImage ? (
                    <div className="flex flex-row items-center justify-center space-x-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-800 ring-1 ring-indigo-500"><img src={URL.createObjectURL(config.referenceImage)} alt="Ref" className="w-full h-full object-cover" /></div>
                      <p className="text-xs font-medium text-white truncate max-w-[120px]">{config.referenceImage.name}</p>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfig(prev => ({ ...prev, referenceImage: null }));
                          if (referenceInputRef.current) referenceInputRef.current.value = '';
                        }}
                        className="p-1.5 hover:bg-zinc-700/50 rounded-full text-zinc-400 hover:text-zinc-200 transition-colors"
                        title="Remove reference image"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                     <div className="flex items-center justify-center space-x-2">
                        <Sparkles className="w-4 h-4 text-zinc-500" />
                        <span className="text-xs text-zinc-400">Upload style reference</span>
                     </div>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium text-zinc-400">Aspect Ratio</label>
                <div className="grid grid-cols-2 gap-2">
                   <select 
                    value