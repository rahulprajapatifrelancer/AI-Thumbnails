import { GoogleGenAI } from "@google/genai";

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the data URL prefix (e.g., "data:image/png;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
  });
};

export const generateThumbnail = async (
  title: string,
  description: string,
  headshotFile: File,
  referenceFile: File | null,
  stylePrompt: string,
  aspectRatio: string,
  textEffect: string
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const base64Headshot = await fileToBase64(headshotFile);
    let base64Reference = null;
    if (referenceFile) {
      base64Reference = await fileToBase64(referenceFile);
    }

    // Using gemini-2.5-flash-image for standard generation
    const model = 'gemini-2.5-flash-image';

    // Note: We are now asking for NO text in the image so the user can position it manually.
    let prompt = `Create a professional YouTube thumbnail background (${aspectRatio} aspect ratio).
    
    CORE ELEMENTS:
    1. Subject: Use the person in the FIRST image provided. Crop them professionally (usually waist-up or head-and-shoulders).
    2. Composition: Place the subject on one side (Rule of Thirds) and leave CLEAR NEGATIVE SPACE on the other side. This negative space is where I will overlay text programmatically.
    ${description ? `3. Context/Background: ${description} (Use this to inform the background elements, mood, and any props)` : ''}
    
    DIRECTION:
    - Match the subject's facial expression to the tone of the title: "${title}".
    - Ensure high contrast and saturation.
    - Add subtle outer glow or rim lighting to the subject.
    - IMPORTANT: DO NOT INCLUDE ANY TEXT IN THE GENERATED IMAGE. I will add the title text myself.
    - INTENDED TEXT STYLE: The text overlay will be "${textEffect}" style. Ensure the background composition and lighting supports this text style.
    `;

    // Explicitly type the array to allow both inlineData and text parts
    const parts: { text?: string; inlineData?: { mimeType: string; data: string } }[] = [
      {
        inlineData: {
          mimeType: headshotFile.type,
          data: base64Headshot
        }
      }
    ];

    if (base64Reference && referenceFile) {
      parts.push({
        inlineData: {
          mimeType: referenceFile.type,
          data: base64Reference
        }
      });
      prompt += `\n
      STYLE REFERENCE:
      - I have provided a second image as a STYLE REFERENCE.
      - Analyze the lighting, color palette, composition, and background style of the SECOND image.
      - Apply this visual style to the scene you create with the subject from the FIRST image.
      - Do NOT copy the specific person or content from the second image, only the aesthetic style and vibe.
      - VISUAL STYLE PRIORITY: Prioritize the style of the reference image over the generic style prompts.
      `;
    } else {
      prompt += `\n- VISUAL STYLE: ${stylePrompt}.`;
    }

    prompt += `\n
    OUTPUT:
    - A single high-quality image without text.
    `;

    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: parts
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          // imageSize is not supported in Flash Image
        }
      }
    });

    // Iterate through parts to find the image
    const responseParts = response.candidates?.[0]?.content?.parts;
    if (!responseParts) {
      throw new Error("No content generated");
    }

    for (const part of responseParts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("No image data found in response");

  } catch (error) {
    console.error("Error generating thumbnail:", error);
    throw error;
  }
};